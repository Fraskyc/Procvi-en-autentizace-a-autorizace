const express = require('express');
const sqlite3 = require('sqlite3').verbose();
const bcrypt = require('bcrypt');
const session = require('express-session');
const bodyParser = require('body-parser');
const app = express();
const PORT = 3000;

app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(express.static('public'));

app.use(session({
  secret: 'tajnyklic',
  resave: false,
  saveUninitialized: true
}));

// Databaze
const db = new sqlite3.Database('./users.db');
db.run(`CREATE TABLE IF NOT EXISTS users (
  id INTEGER PRIMARY KEY AUTOINCREMENT,
  username TEXT UNIQUE,
  name TEXT,
  email TEXT,
  password TEXT
)`);

// kontrola přihlášení
function checkAuth(req, res, next) {
  if (req.session.userId) {
    next();
  } else {
    res.status(401).json({ message: 'Neautorizováno' });
  }
}

// Registrace
app.post('/register', async (req, res) => {
  const { username, name, email, password } = req.body;
  if (!username || !name || !email || !password) return res.status(400).json({ message: 'Vyplňte všechna pole.' });

  const hashedPassword = await bcrypt.hash(password, 10);
  db.run(`INSERT INTO users (username, name, email, password) VALUES (?, ?, ?, ?)`,
    [username, name, email, hashedPassword],
    function (err) {
      if (err) {
        return res.status(500).json({ message: 'Uživatel existuje nebo chyba databáze.' });
      }
      res.json({ message: 'Registrace úspěšná!' });
    });
});

// Přihlášení
app.post('/login', (req, res) => {
  const { username, password } = req.body;
  db.get(`SELECT * FROM users WHERE username = ?`, [username], async (err, user) => {
    if (err || !user) return res.status(400).json({ message: 'Neplatné přihlašovací údaje.' });

    const valid = await bcrypt.compare(password, user.password);
    if (!valid) return res.status(400).json({ message: 'Neplatné heslo.' });

    req.session.userId = user.id;
    res.json({ message: 'Přihlášení úspěšné!' });
  });
});

// Získat údaje přihlášeného uživatele
app.get('/profile', checkAuth, (req, res) => {
  db.get(`SELECT username, name, email FROM users WHERE id = ?`, [req.session.userId], (err, user) => {
    if (err || !user) return res.status(404).json({ message: 'Uživatel nenalezen.' });
    res.json(user);
  });
});

// Úprava profilu
app.post('/profile', checkAuth, (req, res) => {
  const { name, email } = req.body;
  db.run(`UPDATE users SET name = ?, email = ? WHERE id = ?`,
    [name, email, req.session.userId],
    function (err) {
      if (err) return res.status(500).json({ message: 'Chyba při ukládání.' });
      res.json({ message: 'Profil upraven.' });
    });
});

// Odhlášení
app.post('/logout', (req, res) => {
  req.session.destroy();
  res.json({ message: 'Odhlášení úspěšné.' });
});

app.listen(PORT, () => console.log(`Server běží na http://localhost:${PORT}`));
